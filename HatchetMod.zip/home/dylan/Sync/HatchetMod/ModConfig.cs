namespace HatchetMod;

internal class ModConfig
{
    /// <summary>
    /// When false: the Hatchet is replaced by a Pickaxe of the same upgrade level.
    /// If the save was started with this mod (no separate axe was ever given),
    /// a Basic Axe is also restored.
    /// </summary>
    public bool Enabled { get; set; } = true;
}
