using System.Linq;
using HarmonyLib;
using HatchetMod.Integration;
using HatchetMod.Patches;
using StardewModdingAPI;
using StardewModdingAPI.Events;

namespace HatchetMod;

public class ModEntry : Mod
{
    internal static ModEntry Instance { get; private set; } = null!;
    internal static IMonitor Log => Instance.Monitor;

    internal HatchetManager Manager { get; private set; } = null!;
    internal ModConfig Config { get; private set; } = null!;

    private bool _lastKnownEnabled;
    // True for one tick after a toggle so inventory conversion runs after SMAPI propagates assets.
    private bool _pendingConvert;

    public override void Entry(IModHelper helper)
    {
        Instance = this;
        Config   = helper.ReadConfig<ModConfig>();
        Manager  = new HatchetManager(helper);

        helper.Events.GameLoop.GameLaunched  += OnGameLaunched;
        helper.Events.GameLoop.SaveCreated   += OnSaveCreated;
        helper.Events.GameLoop.SaveLoaded    += OnSaveLoaded;
        helper.Events.GameLoop.UpdateTicked  += OnUpdateTicked;
        helper.Events.Content.AssetRequested += OnAssetRequested;

        Monitor.Log("Hatchet mod loaded.", LogLevel.Info);
    }

    private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
    {
        var harmony = new Harmony(ModManifest.UniqueID);
        PickaxePatches.Apply(harmony);
        Monitor.Log("Harmony patches applied.", LogLevel.Debug);

        LogDrawMethods();
        RegisterGmcm();
    }

    /// <summary>
    /// Logs all draw-related methods on Tool, Pickaxe, and Farmer so we can find
    /// the correct patch target for the swing animation (drawDuringUse or equivalent).
    /// </summary>
    private void LogDrawMethods()
    {
        var flags = System.Reflection.BindingFlags.Instance
                  | System.Reflection.BindingFlags.Public
                  | System.Reflection.BindingFlags.NonPublic
                  | System.Reflection.BindingFlags.DeclaredOnly;

        foreach (var type in new[] {
            typeof(StardewValley.Tools.Pickaxe),
            typeof(StardewValley.Tool),
            typeof(StardewValley.Item),
            typeof(StardewValley.Farmer) })
        {
            var drawMethods = type.GetMethods(flags)
                .Where(m => m.Name.Contains("draw", StringComparison.OrdinalIgnoreCase))
                .ToList();

            Monitor.Log($"[Hatchet-Probe] {type.Name} draw methods ({drawMethods.Count}):", LogLevel.Info);
            foreach (var m in drawMethods)
            {
                var parms = string.Join(", ",
                    m.GetParameters().Select(p => $"{p.ParameterType.Name} {p.Name}"));
                Monitor.Log($"  {m.Name}({parms})", LogLevel.Info);
            }
        }
    }

    private void OnSaveCreated(object? sender, SaveCreatedEventArgs e)
    {
        if (Config.Enabled)
            Manager.OnNewGame();
    }

    private void OnSaveLoaded(object? sender, SaveLoadedEventArgs e)
    {
        _lastKnownEnabled = Config.Enabled;
        Manager.OnSaveLoaded(Config.Enabled);
    }

    private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
    {
        PickaxePatches.OnUpdateTicked();

        if (!Context.IsWorldReady) { _lastKnownEnabled = Config.Enabled; return; }

        // Deferred inventory conversion: runs the tick AFTER asset invalidation so that
        // SMAPI has already propagated Data/Tools before we call ItemRegistry.Create.
        if (_pendingConvert)
        {
            _pendingConvert = false;
            if (!Config.Enabled)
                Manager.ConvertHatchetToPickaxe(forceAll: true);
            else
                Manager.OnSaveLoaded(enabled: true);
        }

        if (Config.Enabled == _lastKnownEnabled) return;
        _lastKnownEnabled = Config.Enabled;

        // Invalidate assets this tick; inventory conversion deferred to next tick.
        Helper.GameContent.InvalidateCache("TileSheets/tools");
        Helper.GameContent.InvalidateCache("Data/Tools");
        // ResetToolSpriteSheet reloads _toolSpriteSheet through the game's own content
        // pipeline (which SMAPI intercepts). The cache is stale, so OnAssetRequested
        // fires immediately with the current Config.Enabled and updates the sprite sheet.
        HarmonyLib.AccessTools.Method(typeof(StardewValley.Game1), "ResetToolSpriteSheet")
            ?.Invoke(null, null);
        _pendingConvert = true;
    }

    private void OnAssetRequested(object? sender, AssetRequestedEventArgs e)
    {
        // Only inject hatchet assets when the mod is enabled.
        if (!Config.Enabled) return;

        if (e.NameWithoutLocale.IsEquivalentTo("TileSheets/tools"))
            Manager.EditToolsSpriteSheet(e);

        if (e.NameWithoutLocale.IsEquivalentTo("Data/Tools"))
            Manager.EditToolsData(e);

        if (e.NameWithoutLocale.IsEquivalentTo(HatchetManager.HatchetAAssetPath))
            e.LoadFromModFile<Microsoft.Xna.Framework.Graphics.Texture2D>("assets/hatchet_a.png",
                AssetLoadPriority.Medium);
    }

    // ── Generic Mod Config Menu ───────────────────────────────────────────────

    private void RegisterGmcm()
    {
        var gmcm = Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
        if (gmcm is null) return;

        gmcm.Register(
            mod:   ModManifest,
            reset: () => Config = new ModConfig(),
            save:  () => Helper.WriteConfig(Config));

        gmcm.AddBoolOption(
            mod:      ModManifest,
            getValue: () => Config.Enabled,
            setValue: v =>
            {
                Config.Enabled = v;
                Helper.WriteConfig(Config);
                // Actual conversion and cache invalidation are handled in OnUpdateTicked.
            },
            name:    () => "Enabled",
            tooltip: () => "When off, the Hatchet is replaced by a Pickaxe of the same level. " +
                           "If this save was started with the mod, a Basic Axe is also restored.");
    }
}
