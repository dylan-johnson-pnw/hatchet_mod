using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Extensions;
using StardewValley.Tools;

namespace HatchetMod;

/// <summary>
/// Central manager: asset editing, inventory conversion, save-state tracking.
/// </summary>
internal class HatchetManager
{
    // modData key stamped on every Hatchet item so we can identify them across sessions.
    internal const string ModDataKey = "HatchetMod/isHatchet";

    // SMAPI asset path for the wood-cutting variant (used for future runtime texture swap).
    internal const string HatchetAAssetPath = "Mods/HatchetMod/hatchet_a";

    private readonly IModHelper _helper;

    // ── Save-scoped state ────────────────────────────────────────────────────
    private HatchetState _state = new();

    internal HatchetManager(IModHelper helper)
    {
        _helper = helper;
    }

    // ── Save lifecycle ───────────────────────────────────────────────────────

    internal void OnNewGame()
    {
        if (!Context.IsWorldReady) return;

        // Remove both starting axe and pickaxe; give a Basic Hatchet instead.
        var player = Game1.player;
        for (int i = player.Items.Count - 1; i >= 0; i--)
            if (player.Items[i] is Axe or Pickaxe)
                player.Items[i] = null;

        var hatchet = MakeHatchet(upgradeLevel: 0);
        player.addItemByMenuIfNecessary(hatchet);

        _state = new HatchetState { NewGameStarted = true, ConversionDone = true };
        SaveState();

        ModEntry.Log.Log("[Hatchet] New game: axe + pickaxe removed, Basic Hatchet given.", LogLevel.Info);
    }

    internal void OnSaveLoaded(bool enabled)
    {
        if (!Context.IsWorldReady) return;
        _state = LoadState();

        if (!enabled)
        {
            // Mod is disabled: if there's a hatchet in inventory, revert it.
            if (_state.ConversionDone)
                ConvertHatchetToPickaxe();
            return;
        }

        if (!_state.ConversionDone)
            ConvertPickaxeToHatchet();
    }

    // ── Inventory conversion ─────────────────────────────────────────────────

    /// <summary>
    /// Find the player's pickaxe and swap it for a Hatchet at the same upgrade level.
    /// Called once when the mod is first installed on an existing save.
    /// </summary>
    private void ConvertPickaxeToHatchet()
    {
        var player = Game1.player;
        for (int i = 0; i < player.Items.Count; i++)
        {
            if (player.Items[i] is not Pickaxe pick) continue;
            if (IsHatchet(pick)) continue; // already converted

            var hatchet = MakeHatchet(pick.UpgradeLevel);
            player.Items[i] = hatchet;
            ModEntry.Log.Log($"[Hatchet] Converted pickaxe (level {pick.UpgradeLevel}) to Hatchet.", LogLevel.Info);
        }

        _state.ConversionDone = true;
        SaveState();
    }

    /// <summary>
    /// Reverse: replace all Hatchets with Pickaxes at the same upgrade level.
    /// If this was a new-game save, also give a Basic Axe (the player never had one).
    /// Called when the mod is disabled via config.
    /// <param name="forceAll">
    /// When true, converts every Pickaxe in inventory without the IsHatchet check.
    /// Use when disabling the mod: while enabled, all pickaxes ARE hatchets, but Data/Tools
    /// names may have already been reverted so the DisplayName fallback in IsHatchet could fail.
    /// </param>
    /// </summary>
    internal void ConvertHatchetToPickaxe(bool forceAll = false)
    {
        var player = Game1.player;
        bool restored = false;

        for (int i = 0; i < player.Items.Count; i++)
        {
            if (player.Items[i] is not Pickaxe pick) continue;
            if (!forceAll && !IsHatchet(pick)) continue;

            // Use ItemRegistry.Create so CurrentParentTileIndex and IndexOfMenuItemView
            // are read from Data/Tools (now vanilla after SMAPI propagation) rather than
            // defaulting to the basic-pickaxe values that new Pickaxe() produces.
            var pickaxe = (Pickaxe)ItemRegistry.Create(PickaxeQualifiedId(pick.UpgradeLevel));
            player.Items[i] = pickaxe;
            restored = true;
            ModEntry.Log.Log($"[Hatchet] Restored Pickaxe (level {pick.UpgradeLevel}).", LogLevel.Info);
        }

        if (restored && _state.NewGameStarted)
        {
            player.addItemByMenuIfNecessary(new Axe { UpgradeLevel = 0 });
            ModEntry.Log.Log("[Hatchet] New-game save: also gave Basic Axe.", LogLevel.Info);
        }

        _state.ConversionDone = false;
        SaveState();
    }

    // ── Asset editing ────────────────────────────────────────────────────────

    /// <summary>
    /// Injects hatchet sprites into TileSheets/tools at the pickaxe animation positions.
    /// Phase 2 (sprite injection) lives here.
    /// </summary>
    internal void EditToolsSpriteSheet(AssetRequestedEventArgs e)
    {
        e.Edit(asset =>
        {
            var editor = asset.AsImage();

            // ── Confirmed tools.png layout (from pixel analysis) ─────────────
            // Sheet: 336×384 (21 cols × 24 rows of 16px). Tool animation frames
            // are 16×32 sprites (two consecutive 16px rows). SpriteIndex gives the
            // TOP of the 32px frame. Vanilla content starts at local y≈10 within
            // the 32px frame. The icon (MenuSpriteIndex) sits at the lower 16px
            // (frameTop + 16).
            //
            // hatchet_a / hatchet_b layout (323×61px):
            //   Row 1 (basic/copper/steel): anim content y=4–25, icon content y=10
            //   Row 2 (gold/iridium):       anim content y=36–57, icon content y=42

            const int animW   = 80;  // 5 animation frames × 16px
            const int animH   = 22;  // content height
            const int animOff = 10;  // local y offset into 32px frame
            const int iconW   = 16;
            const int iconH   = 16;

            // Source rows in hatchet_*.png
            const int r1Anim = 4;
            const int r1Icon = 10;
            const int r2Anim = 36;
            const int r2Icon = 42;

            // ── Default sprite: hatchet_b (rock-breaking variant) ────────────
            // Injected at the standard pickaxe SpriteIndex positions:
            //   Basic=105→(0,80)  Copper=112→(112,80)  Steel=119→(224,80)
            //   Gold=147→(0,112)  Iridium=154→(112,112)
            var hatchetB = _helper.ModContent.Load<Texture2D>("assets/hatchet_b.png");

            // Animation frames
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(0,   r1Anim, animW, animH), targetArea: new Rectangle(0,   80  + animOff, animW, animH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(112, r1Anim, animW, animH), targetArea: new Rectangle(112, 80  + animOff, animW, animH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(224, r1Anim, animW, animH), targetArea: new Rectangle(224, 80  + animOff, animW, animH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(0,   r2Anim, animW, animH), targetArea: new Rectangle(0,   112 + animOff, animW, animH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(112, r2Anim, animW, animH), targetArea: new Rectangle(112, 112 + animOff, animW, animH));

            // Menu icons (MenuSpriteIndex: Basic=131→(80,96) Copper=138→(192,96)
            //   Steel=145→(304,96) Gold=173→(80,128) Iridium=180→(192,128))
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(80,  r1Icon, iconW, iconH), targetArea: new Rectangle(80,  96,  iconW, iconH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(192, r1Icon, iconW, iconH), targetArea: new Rectangle(192, 96,  iconW, iconH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(304, r1Icon, iconW, iconH), targetArea: new Rectangle(304, 96,  iconW, iconH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(80,  r2Icon, iconW, iconH), targetArea: new Rectangle(80,  128, iconW, iconH));
            editor.PatchImage(hatchetB, sourceArea: new Rectangle(192, r2Icon, iconW, iconH), targetArea: new Rectangle(192, 128, iconW, iconH));

            // ── Wood-variant sprite: hatchet_a ───────────────────────────────
            // Injected at new rows below the vanilla content (sheet extended from
            // 384 to 448px). 21 cells/row → SpriteIndex = row×21 + col.
            //   Row 24 (y=384): Basic=504  Copper=511  Steel=518
            //   Row 26 (y=416): Gold=546   Iridium=553
            // Only animation frames needed — icon stays hatchet_b (no swap during swing).
            editor.ExtendImage(336, 448);
            var hatchetA = _helper.ModContent.Load<Texture2D>("assets/hatchet_a.png");

            editor.PatchImage(hatchetA, sourceArea: new Rectangle(0,   r1Anim, animW, animH), targetArea: new Rectangle(0,   384 + animOff, animW, animH));
            editor.PatchImage(hatchetA, sourceArea: new Rectangle(112, r1Anim, animW, animH), targetArea: new Rectangle(112, 384 + animOff, animW, animH));
            editor.PatchImage(hatchetA, sourceArea: new Rectangle(224, r1Anim, animW, animH), targetArea: new Rectangle(224, 384 + animOff, animW, animH));
            editor.PatchImage(hatchetA, sourceArea: new Rectangle(0,   r2Anim, animW, animH), targetArea: new Rectangle(0,   416 + animOff, animW, animH));
            editor.PatchImage(hatchetA, sourceArea: new Rectangle(112, r2Anim, animW, animH), targetArea: new Rectangle(112, 416 + animOff, animW, animH));
        });
    }

    /// <summary>
    /// Renames all Pickaxe entries in Data/Tools to Hatchet and sets custom upgrade costs.
    /// Phase 3 + Phase 4.
    /// </summary>
    internal void EditToolsData(AssetRequestedEventArgs e)
    {
        e.Edit(asset =>
        {
            var data = asset.AsDictionary<string, StardewValley.GameData.Tools.ToolData>().Data;

            // (key, displayName, requiresId, barId, barCount, price)
            // barCount=0 means no UpgradeFrom (the basic Hatchet can't be upgraded TO via Clint).
            var entries = new[]
            {
                ("Pickaxe",       "Hatchet",         null,               null,     0,       0),
                ("CopperPickaxe", "Copper Hatchet",  "(T)Pickaxe",       "(O)334", 8,  3_000),
                ("SteelPickaxe",  "Steel Hatchet",   "(T)CopperPickaxe", "(O)335", 8,  7_500),
                ("GoldPickaxe",   "Gold Hatchet",    "(T)SteelPickaxe",  "(O)336", 8, 15_000),
                ("IridiumPickaxe","Iridium Hatchet", "(T)GoldPickaxe",   "(O)337", 8, 37_500),
            };

            foreach (var (key, displayName, requiresId, barId, barCount, price) in entries)
            {
                if (!data.TryGetValue(key, out var entry)) continue;

                entry.DisplayName = displayName;
                entry.Name        = displayName;
                entry.Description = "Chops wood and breaks rocks. One tool, one slot.";

                // Replace ConventionalUpgradeFrom with a custom UpgradeFrom spec
                // so we can set 8 bars and 150% price. The basic Hatchet (level 0)
                // has no upgrade requirements.
                entry.ConventionalUpgradeFrom = null;
                entry.UpgradeFrom = null; // clear any vanilla UpgradeFrom before we conditionally set it

                if (barCount > 0)
                {
                    entry.UpgradeFrom =
                    [
                        new StardewValley.GameData.Tools.ToolUpgradeData
                        {
                            RequireToolId   = requiresId,
                            TradeItemId     = barId,
                            TradeItemAmount = barCount,
                            Price           = price,
                        }
                    ];
                }
            }
        });
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    internal static bool IsHatchet(Item? item)
    {
        if (item is not Pickaxe pick) return false;
        // Primary: modData flag (set when we create the hatchet).
        if (pick.modData.ContainsKey(ModDataKey)) return true;
        // Fallback: when the mod is enabled, ALL pickaxes are hatchets because
        // EditToolsData renames every Data/Tools Pickaxe entry to "Hatchet".
        // Clint's upgrade drops the modData flag on the returned tool, so we
        // identify it by the display name that our data edit provides dynamically.
        return pick.DisplayName.Contains("Hatchet", StringComparison.OrdinalIgnoreCase);
    }

    private static Pickaxe MakeHatchet(int upgradeLevel)
    {
        // ItemRegistry.Create reads Data/Tools (currently hatchet-modified) so the
        // returned Pickaxe has the correct SpriteIndex, MenuSpriteIndex, and display name.
        var pick = (Pickaxe)ItemRegistry.Create(PickaxeQualifiedId(upgradeLevel));
        pick.modData[ModDataKey] = "1";
        return pick;
    }

    private static string PickaxeQualifiedId(int upgradeLevel) => upgradeLevel switch
    {
        1 => "(T)CopperPickaxe",
        2 => "(T)SteelPickaxe",
        3 => "(T)GoldPickaxe",
        4 => "(T)IridiumPickaxe",
        _ => "(T)Pickaxe",
    };

    // ── Persistence ──────────────────────────────────────────────────────────

    private HatchetState LoadState() =>
        _helper.Data.ReadSaveData<HatchetState>("state") ?? new HatchetState();

    private void SaveState() =>
        _helper.Data.WriteSaveData("state", _state);
}

/// <summary>Per-save state persisted via SMAPI's save data API.</summary>
internal class HatchetState
{
    /// <summary>True if this save was started with the Hatchet mod active (no axe was ever given).</summary>
    public bool NewGameStarted { get; set; }

    /// <summary>True once the initial pickaxe→hatchet conversion has run for this save.</summary>
    public bool ConversionDone { get; set; }
}
