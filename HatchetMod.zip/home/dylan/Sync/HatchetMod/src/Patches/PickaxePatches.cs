using HarmonyLib;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.TerrainFeatures;
using StardewValley.Tools;

namespace HatchetMod.Patches;

/// <summary>
/// Phase 5 patches on Pickaxe:
///   5a — DoFunction postfix: adds axe behavior so the Hatchet also cuts wood.
///   5b — beginUsing prefix + tile detection: sets _useWoodVariant flag.
///        Wood-variant sprite switching is pending (drawDuringUse exists only on
///        MeleeWeapon; correct approach is to inject hatchet_a into tools.png at
///        alternate SpriteIndex positions and swap CurrentParentTileIndex transiently).
/// </summary>
[HarmonyPatch]
internal static class PickaxePatches
{
    // Set in beginUsing; cleared in UpdateTicked once the swing ends.
    private static bool _useWoodVariant;

    internal static void Apply(Harmony harmony)
    {
        // Attribute-patched methods (DoFunction, beginUsing):
        harmony.CreateClassProcessor(typeof(PickaxePatches)).Patch();
    }

    // ── 5a: Axe behavior ─────────────────────────────────────────────────────

    [HarmonyPostfix]
    [HarmonyPatch(typeof(Pickaxe), nameof(Pickaxe.DoFunction))]
    private static void Pickaxe_DoFunction_Postfix(
        GameLocation location, int x, int y, int power, Farmer who)
    {
        if (!ModEntry.Instance.Config.Enabled) return;
        // Apply axe behavior to ANY pickaxe while the mod is enabled.
        // This means even if the item/sprite hasn't swapped yet (e.g. after a
        // live toggle without restart), the tool still chops wood at the correct level.
        if (who.CurrentTool is not Pickaxe pick) return;

        var axe = new Axe { UpgradeLevel = pick.UpgradeLevel };
        axe.DoFunction(location, x, y, power, who);
    }

    // ── 5b: Texture switching ─────────────────────────────────────────────────

    /// <summary>
    /// Called after beginUsing sets up the swing. Overrides CurrentParentTileIndex
    /// to the hatchet_a (wood-variant) positions when targeting trees/logs/stumps.
    /// Must be a postfix — beginUsing body resets CurrentParentTileIndex to
    /// InitialParentTileIndex + frameOffset, undoing any prefix change.
    /// We preserve the same frameOffset so the correct animation frame is shown.
    /// </summary>
    [HarmonyPostfix]
    [HarmonyPatch(typeof(Pickaxe), nameof(Pickaxe.beginUsing))]
    private static void Pickaxe_BeginUsing_Postfix(
        GameLocation location, int x, int y, Farmer who)
    {
        if (!ModEntry.Instance.Config.Enabled) return;
        if (who.CurrentTool is not Pickaxe pick) return;

        var tile = new Vector2(x / Game1.tileSize, y / Game1.tileSize);
        _useWoodVariant = IsWoodTarget(location, tile, (int)tile.X, (int)tile.Y);

        if (_useWoodVariant)
        {
            // Preserve the frame offset that beginUsing chose (e.g. 156 = 154+2 for iridium)
            // so we land on the equivalent frame position within the wood-variant strip.
            int frameOffset = pick.CurrentParentTileIndex - pick.InitialParentTileIndex;
            pick.CurrentParentTileIndex = WoodSpriteIndex(pick.UpgradeLevel) + frameOffset;
        }
    }

    /// <summary>
    /// Called every tick from ModEntry. Restores the default (hatchet_b) sprite
    /// once the swing animation ends.
    /// </summary>
    internal static void OnUpdateTicked()
    {
        if (!_useWoodVariant) return;
        if (Game1.player?.UsingTool == true) return;

        if (Game1.player?.CurrentTool is Pickaxe pick)
            pick.CurrentParentTileIndex = RockSpriteIndex(pick.UpgradeLevel);

        _useWoodVariant = false;
    }

    // ── Sprite index helpers ──────────────────────────────────────────────────

    // Default (hatchet_b) positions — standard pickaxe SpriteIndex values.
    private static int RockSpriteIndex(int upgradeLevel) => upgradeLevel switch
    {
        1 => 112,
        2 => 119,
        3 => 147,
        4 => 154,
        _ => 105,
    };

    // Wood-variant (hatchet_a) positions — injected at rows 24/26 of tools.png
    // (sheet extended to 448px). Row 24 y=384 → SpriteIndex 504; row 26 y=416 → 546.
    // 21 cells/row: Basic=504 Copper=511 Steel=518 Gold=546 Iridium=553
    private static int WoodSpriteIndex(int upgradeLevel) => upgradeLevel switch
    {
        1 => 511,
        2 => 518,
        3 => 546,
        4 => 553,
        _ => 504,
    };

    // ── Tile detection ────────────────────────────────────────────────────────

    private static bool IsWoodTarget(GameLocation location, Vector2 tile, int tx, int ty)
    {
        // Trees and saplings
        if (location.terrainFeatures.TryGetValue(tile, out var feature) &&
            feature is Tree or FruitTree or Bush)
            return true;

        foreach (var clump in location.resourceClumps)
        {
            if (!clump.occupiesTile(tx, ty)) continue;
            int idx = clump.parentSheetIndex.Value;
            if (idx is 600 or 602) return true;  // large stump / large log = wood
            return false;                          // boulders etc. = rock
        }

        return false;
    }
}
